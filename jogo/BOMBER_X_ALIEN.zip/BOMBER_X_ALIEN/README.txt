PROJETO FINAL 2025.1 ISC

GRUPO:

Eduardo Sankievicz Lima
Danilo Lins Castro
João Vítor da Silva Lima

Como jogar:

W, A, S, D - movimentação
J - posiciona a bomba

Cheats:

1 - vai para a fase 1
2 - vai para a fase 2
3 - power up força
4 - power up velocidade

Obs: use o FPGRARS. Em sistemas Linux, é possível que seja necessário baixar o timidity, assim como descrito
em https://leoriether.github.io/FPGRARS/midi/

Comando linux: ./fpgrars_linux main.s -w 640 -h 480 --port "alguma das portas de áudio - teste de 0 a 3 até que saia música no menu"

Comando windows: fpgrars_windows.exe main.s -h 480 -w 640
